const botaoMenu = document.querySelector('.buto12');
const asideMenu = document.getElementById('asideMenu');
const containerExterno = document.querySelector('.container_externo');
const backdrop = document.getElementById('backdrop');

botaoMenu.addEventListener('click', (e) => {
    e.stopPropagation(); 
    asideMenu.classList.add('active');
    backdrop.classList.add('active');
});

backdrop.addEventListener('click', () => {
    asideMenu.classList.remove('active');
    backdrop.classList.remove('active');
});

containerExterno.addEventListener('click', (e) => {
    if (!asideMenu.contains(e.target) && !botaoMenu.contains(e.target)) {
        asideMenu.classList.remove('active');
        backdrop.classList.remove('active');
    }
});

asideMenu.addEventListener('click', (e) => {
    e.stopPropagation();
});