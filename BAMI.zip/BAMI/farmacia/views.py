from datetime import date
from django.shortcuts import render
from .models import Medicamento, Transacao

def listar_medicamentos_validos(request):
    validos = Medicamento.objects.filter(data_validade__gte=date.today())
    return render(request, 'farmacia/index.html', {'medicamentos': validos})

def listar_medicamentos_vencidos(request):
    vencidos = Medicamento.objects.filter(data_validade__lt=date.today())
    return render(request, 'farmacia/vencidos.html', {'medicamentos': vencidos})

def listar_transacoes(request):
    transacoes = Transacao.objects.all().order_by('-data')
    return render(request, 'farmacia/transacoes.html', {'transacoes': transacoes})