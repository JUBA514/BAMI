from django.urls import path
from . import views

urlpatterns = [
    path('', views.listar_medicamentos_validos, name='index'),
    path('transacoes/', views.listar_transacoes, name='transacoes'),
    path('vencidos/', views.listar_medicamentos_vencidos, name='vencidos'),
]