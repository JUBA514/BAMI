from django.db import models

class Medicamento(models.Model):
    nome_farmaceutico = models.CharField(max_length=255)
    nome_comercial = models.CharField(max_length=255, blank=True, null=True)
    numero_identificacao = models.CharField(max_length=100, unique=True)
    local = models.CharField(max_length=100)
    tipo = models.CharField(max_length=100)
    quantidade = models.IntegerField()
    unidade_medida = models.CharField(max_length=50)
    data_validade = models.DateField()

    def __str__(self):
        return self.nome_farmaceutico

    #class Funcionario(models.Model):
    #     nome = models.CharField(max_length=255)
    #     email = models.EmailField(unique=True)
    #     cargo = models.CharField(max_length=100)

class Transacao(models.Model):
        TIPO_CHOICES = [
            ('entrada', 'Entrada'),
            ('saida', 'Saída'),
            ('ajuste', 'Ajuste'),
        ]
        medicamento = models.ForeignKey(Medicamento, on_delete=models.CASCADE)
        tipo_transacao = models.CharField(max_length=10, choices=TIPO_CHOICES)
        quantidade = models.IntegerField()
        data = models.DateTimeField(auto_now_add=True)
        #funcionario = models.ForeignKey(Funcionario, on_delete=models.SET_NULL, null=True)

        def __str__(self):
            return f"{self.tipo_transacao} - {self.medicamento.nome_farmaceutico} ({self.quantidade})"