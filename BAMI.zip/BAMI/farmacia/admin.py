from .models import Medicamento, Transacao #Funcionario
from django.contrib import admin

admin.site.register(Medicamento)
#admin.site.register(Funcionario)
admin.site.register(Transacao)
